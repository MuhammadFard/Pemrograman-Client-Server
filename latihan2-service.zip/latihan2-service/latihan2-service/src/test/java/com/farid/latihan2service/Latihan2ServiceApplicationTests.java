package com.farid.latihan2service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Latihan2ServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
