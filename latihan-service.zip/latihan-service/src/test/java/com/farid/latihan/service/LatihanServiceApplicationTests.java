package com.farid.latihan.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LatihanServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
